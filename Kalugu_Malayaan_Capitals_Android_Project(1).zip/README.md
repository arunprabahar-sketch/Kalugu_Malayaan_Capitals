# KALUGU MALAYAAN CAPITALS — Android build

This project packages the current HTML finance app in an Android WebView and adds a native Android biometric/device-credential gate.

## Build in GitHub from an Android phone
1. Create a new **public or private** GitHub repository named `Kalugu-Malayaan-Capitals`.
2. Extract this ZIP on your phone.
3. Upload the extracted project files and folders to the repository root (the `.github` folder must be included).
4. Open the repository's **Actions** tab.
5. Select **Build Android APK** and tap **Run workflow** (or push to `main`).
6. When the run completes, open it and download the artifact named `Kalugu-Malayaan-Capitals-debug-apk`.
7. Extract the artifact ZIP and install `app-debug.apk`. Android may ask you to allow installation from your browser/file manager.

## Important limitations
- This is a debug APK for testing, not a Play Store release or a signed production release.
- Native biometric/device-credential authentication is added before the app opens. The existing in-app PIN remains as a second access step.
- SMS OTP is **not configured**. A real OTP workflow requires an SMS provider account/API credentials and a secure server-side verification endpoint. Do not put SMS provider secrets in the Android app or GitHub source.
- Existing app records are stored locally in the WebView browser database. This build does not provide cloud sync or encrypted database storage. Back up records regularly.
- The HTML app's service-worker/PWA registration is not used inside the packaged APK.
